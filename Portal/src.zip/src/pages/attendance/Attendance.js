import React from "react";

// components
import PageTitle from "../../components/PageTitle";

export default function AttendancePage() {

  return (
    <>
      <PageTitle title="Attendance Management" />
      <h2>(Coming Soon...)</h2>
    </>
  );
}