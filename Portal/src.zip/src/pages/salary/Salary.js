import React from "react";

// components
import PageTitle from "../../components/PageTitle/PageTitle";

export default function SalaryPage() {
  return (
    <>
      <PageTitle title="Salary Management" />
      <h2>(Coming Soon...)</h2>
    </>
  );
}